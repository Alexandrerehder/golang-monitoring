package main

// An Example function must have an "Output:" comment for the go build
// system to generate a call to it from the test main package.

func Example() {
	C(0).f()

	// Output:
}
